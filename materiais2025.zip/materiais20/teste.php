<?php
echo "PHP FUNCIONANDO";
