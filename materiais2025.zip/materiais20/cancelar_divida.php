<?php
include "conexao.php";
require_once "proteger.php";
<meta name="viewport" content="width=device-width, initial-scale=1">

if (!isset($_SESSION['admin_confirmado'])) {
    header("Location: pedir_confirmacao.php?redirect=adicionar_pagamento.php&id=".$_GET['id']);
    exit;
}

if($_SERVER['REQUEST_METHOD'] === 'POST'){

    $id_devedor = intval($_POST['id_devedor']);
    $usuario = $_POST['usuario_admin'];
    $senha = $_POST['senha_admin'];

    // Buscar usuário
    $stmt = $conn->prepare("
        SELECT id, senha, nivel, tentativas, bloqueado_ate 
        FROM usuarios 
        WHERE usuario = ?
        LIMIT 1
    ");
    $stmt->bind_param("s", $usuario);
    $stmt->execute();
    $result = $stmt->get_result();

    if($result->num_rows == 0){
        die("Usuário não encontrado");
    }

    $user = $result->fetch_assoc();

    // Verificar se está bloqueado
    if($user['bloqueado_ate'] && strtotime($user['bloqueado_ate']) > time()){
        die("Usuário bloqueado temporariamente");
    }

    // Verificar senha
    if(!password_verify($senha, $user['senha'])){

        // Incrementar tentativas
        $tentativas = $user['tentativas'] + 1;
        $bloqueado_ate = NULL;

        if($tentativas >= 3){
            $bloqueado_ate = date("Y-m-d H:i:s", strtotime("+5 minutes"));
        }

        $stmt = $conn->prepare("
            UPDATE usuarios 
            SET tentativas = ?, bloqueado_ate = ?
            WHERE id = ?
        ");
        $stmt->bind_param("isi", $tentativas, $bloqueado_ate, $user['id']);
        $stmt->execute();

        echo "<script>alert('Senha incorreta'); window.history.back();</script>";
        exit;
    }

    // Resetar tentativas ao acertar
    $stmt = $conn->prepare("
        UPDATE usuarios 
        SET tentativas = 0, bloqueado_ate = NULL
        WHERE id = ?
    ");
    $stmt->bind_param("i", $user['id']);
    $stmt->execute();

    // Verificar se é admin
    if($user['nivel'] !== 'admin'){
        die("Apenas administradores podem cancelar dívida");
    }

    // Cancelar dívida
    $stmt = $conn->prepare("
        UPDATE devedores 
        SET status_divida = 'CANCELADA' 
        WHERE id_devedor = ?
    ");
    $stmt->bind_param("i", $id_devedor);

    if($stmt->execute()){
        echo "<script>alert('Dívida cancelada com sucesso'); window.location='devedores.php';</script>";
    } else {
        echo "Erro: ".$conn->error;
    }
}
?>