<?php
require_once "proteger.php"; // valida sessão
include "conexao.php";
<meta name="viewport" content="width=device-width, initial-scale=1">

// Obter ID do devedor
$id = $_GET['id'];

// Verificar se o pagamento foi enviado
if (isset($_POST['salvar_pagamento'])) {

    $valor_pago = $_POST['valor_pago'];
    $data_pagamento = $_POST['data_pagamento'];
    $id_devedor = $id; // usa o GET

    // 1. Salvar pagamento
    $stmt = $conn->prepare("
        INSERT INTO pagamentos_divida (id_devedor, valor_pago, data_pagamento)
        VALUES (?, ?, ?)
    ");
   $stmt->bind_param("ids", $id_devedor, $valor_pago, $data_pagamento);
    $stmt->execute();
    $stmt->close();

    // 2. Buscar totais atualizados
    $stmt = $conn->prepare("
        SELECT 
            d.id_venda,
            d.valor_divida,
            IFNULL(SUM(p.valor_pago),0) as total_pago
        FROM devedores d
        LEFT JOIN pagamentos_divida p ON d.id_devedor = p.id_devedor
        WHERE d.id_devedor = ?
    ");
    $stmt->bind_param("i", $id_devedor);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();

    // 3. Definir status
    $status = "ABERTO";

    if($res['total_pago'] >= $res['valor_divida']){
        $status = "PAGO";
    } elseif($res['total_pago'] > 0){
        $status = "PARCIAL";
    }

    // 4. Atualizar venda
    $stmt = $conn->prepare("
        UPDATE vendas SET status = ? WHERE id = ?
    ");
    $stmt->bind_param("si", $status, $res['id_venda']);
    $stmt->execute();

    // 5. Redirecionar
    header("Location: devedores.php");
    exit;
}

// agora buscar dados
$stmt = $conn->prepare("
SELECT 
    d.id_venda,
    d.valor_divida,
    IFNULL(SUM(p.valor_pago),0) as total_pago
FROM devedores d
LEFT JOIN pagamentos_divida p ON d.id_devedor = p.id_devedor
WHERE d.id_devedor = ?
");

$stmt->bind_param("i", $id_devedor);
$stmt->execute();

$res = $stmt->get_result()->fetch_assoc();

$status = "ABERTO";

if($res['total_pago'] >= $res['valor_divida']){
    $status = "PAGO";
} elseif($res['total_pago'] > 0){
    $status = "PARCIAL";
}

// atualizar venda corretamente
$stmt = $conn->prepare("
UPDATE vendas SET status = ? WHERE id = ?
");

$stmt->bind_param("si", $status, $res['id_venda']);
$stmt->execute();

// Obter informações do devedor para exibir no formulário
$stmt = $conn->prepare("SELECT * FROM devedores WHERE id_devedor = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Adicionar Pagamento - Devedor</title>
    <link rel="stylesheet" href="adicionar_pagamento.css">
    
</head>
<body>

<div class="container">

    <h2>Adicionar Pagamento para <?php echo $row['nome_cliente']; ?></h2>

    <form method="POST">
        <div class="input-group">
            <label for="valor_pago">Valor do Pagamento</label>
            <input type="number" name="valor_pago" step="0.01" required>
        </div>

        <div class="input-group">
            <label for="data_pagamento">Data do Pagamento</label>
            <input type="date" name="data_pagamento" required>
        </div>

        <button type="submit" name="salvar_pagamento">Salvar Pagamento</button>
    </form>

</div>

</body>
</html>